//
//  Webservice.swift
//  weatherApp
//
//  Created by Akanksha on 15/02/22.
//

import Foundation

class Webservice {
    private let session: URLSession = {
        let config = URLSessionConfiguration.default
        return URLSession(configuration: config)
    }()

    func getSearchCityWeatherData(searchText:String, completion: @escaping (Result<[LandingDataModel], Error>) -> Void) {
        guard let url = Constants.Urls.urlForWeatherByCity(city: searchText) else {
            return
        }
        let request = URLRequest(url: url)
        let task = session.dataTask(with: request) {
            (data, response, error) in
            let result = self.processWeatherData(data: data, error: error)
            DispatchQueue.main.async {
                completion(result)
            }
            
            
        }
        task.resume()
    }
    func getCityWeatherData(cityKey:String, completion: @escaping (Result<[CityWeatherDataModel], Error>) -> Void) {
        guard let url = Constants.Urls.urlForWeatherByKey(cityKey: cityKey) else {
            return
        }
        let request = URLRequest(url: url)
        let task = session.dataTask(with: request) {
            (data, response, error) in
            
            
            guard let jsonData = data else {
                return completion(.failure(error!))
            }
            do {
                let decoder = JSONDecoder()
                let results = try decoder.decode([CityWeatherDataModel].self, from: jsonData)
                return completion(.success(results))
            } catch {
                return completion(.failure(error))
            }
            
            
        }
        task.resume()
    }
    
    private func processWeatherData(data: Data?,
                                    error: Error?) -> Result<[LandingDataModel],Error> {
        guard let jsonData = data else {
            return .failure(error!)
        }
        do {
            let decoder = JSONDecoder()
            let results = try decoder.decode([LandingDataModel].self, from: jsonData)
            return .success(results)
        } catch {
            return .failure(error)
        }
        
    }
    
    
    
}
