//
//  LandingTableViewController.swift
//  weatherApp
//
//  Created by Akanksha on 17/02/22.
//

import UIKit

class LandingTableViewController: UITableViewController {
    
    @IBOutlet weak var searchBar:UISearchBar!
    var viewModel:LandingViewModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.delegate = self
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
       
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return viewModel.totalNumberOfCities
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "WeatherTableViewCell", for: indexPath) as! WeatherTableViewCell
        cell.cityName.text = viewModel.getCityName(index: indexPath.row)
        cell.temperatureLabel.text = viewModel.getKey(index: indexPath.row)
        return cell
    }
    
    //MARK: - Table view delegate methods
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let resultViewController = storyboard?.instantiateViewController(withIdentifier: "CityWeatherDetailsViewController") as? CityWeatherDetailsViewController else{
            return
        }
        resultViewController.cityKey = viewModel.getKey(index: indexPath.row)
        resultViewController.cityName = viewModel.getCityName(index: indexPath.row)
        self.navigationController?.pushViewController(resultViewController, animated: true)
    }
    

}
//MARK: - Extensions
extension LandingTableViewController : UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        if range.location == 0 && text == " " {
            return false
        }
        return true
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
       
        if searchText.count > 2 {
            
            let requestWorkItem = DispatchWorkItem{ [weak self] in
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { [weak self] in
                    guard let self = self else{
                        return
                    }
                    self.viewModel.getSearchCities(searchText:searchText){
                        (photosResult) in
                        switch photosResult {
                        case .success(_):
                            self.searchBar.resignFirstResponder()
                            DispatchQueue.main.async {
                                self.tableView.reloadData()
                            }
                            
                        case let .failure(error):
                            print(error)
                            
                        }
                    }
                }
            }
           
            DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(1), execute: requestWorkItem)
            
        } else {
            
        }
    }
    
    func searchBarShouldEndEditing(_ searchBar: UISearchBar) -> Bool {
        searchBar.resignFirstResponder()
        return true
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.text = ""
        self.searchBar.showsCancelButton = false
        
    }
    

}
