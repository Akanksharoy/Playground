//
//  AddCityViewController.swift
//  weatherApp
//
//  Created by Akanksha on 14/02/22.
//

import UIKit

class AddCityViewController: UIViewController {
    var searchBar:UISearchBar = UISearchBar()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Add city"
        
    }
}
