//
//  CityWeatherDetailsViewController.swift
//  weatherApp
//
//  Created by Akanksha on 18/02/22.
//

import Foundation
import UIKit
class CityWeatherDetailsViewController:UIViewController{
    @IBOutlet weak var CityName:UILabel!
    @IBOutlet weak var TemperatureLabel:UILabel!
    @IBOutlet weak var ConditionLabel:UILabel!
    @IBOutlet weak var date:UILabel!
    var cityWeatherDetailsViewModel:CityWeatherDetailsViewModel?
    var cityKey:String!
    var cityName:String!
    var activityView: UIActivityIndicatorView?
    var weatherdate :Date?
    
    
    override func viewDidLoad() {
        showActivityIndicator()
        cityWeatherDetailsViewModel = CityWeatherDetailsViewModel(locationKey: cityKey)
        if  let city = self.cityName
        {
            self.title = "Weather of \(city)"
        }
            else{
                self.title = "Weather data"
        }
        
        fetchData()
        
    }
    func fetchData(){
        cityWeatherDetailsViewModel?.getCityData(cityKey: cityKey){[weak self] in
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy'-'MM'-'dd'T'HH':'mm':'ssZZZ"
            if let datestr = self?.cityWeatherDetailsViewModel?.cityWeatherDataModel?[0].localObservationDateTime{
                self?.weatherdate = dateFormatter.date(from: datestr)
            }
            
            DispatchQueue.main.async {
                self?.hideActivityIndicator()
                self?.CityName.text = self?.cityName
                self?.TemperatureLabel.text = self?.cityWeatherDetailsViewModel?.cityWeatherDataModel?[0].temperature.metric.value.description
                self?.ConditionLabel.text = self?.cityWeatherDetailsViewModel?.cityWeatherDataModel?[0].weatherText
                self?.date.text = self?.weatherdate?.description ?? ""
                
                
            }
            
        }
    }
    
    func showActivityIndicator() {
        activityView = UIActivityIndicatorView(style: .large)
        activityView?.center = self.view.center
        self.view.addSubview(activityView!)
        self.view?.bringSubviewToFront(activityView!)
        activityView?.startAnimating()
    }

    func hideActivityIndicator(){
        if (activityView != nil){
            activityView?.stopAnimating()
        }
    }
    
}
