//
//  WeatherTableViewCell.swift
//  weatherApp
//
//  Created by Akanksha on 15/02/22.
//

import Foundation
import UIKit
class WeatherTableViewCell: UITableViewCell{
    @IBOutlet weak var cityName:UILabel!
    @IBOutlet weak var temperatureLabel:UILabel!
    
}
