//
//  LandingDataModel.swift
//  weatherApp
//
//  Created by Akanksha on 16/02/22.
//

import Foundation
struct LandingDataModel:Codable{
    var Key:String
    var LocalizedName:String
}
