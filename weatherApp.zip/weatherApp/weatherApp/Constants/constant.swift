//
//  constant.swift
//  weatherApp
//
//  Created by Akanksha on 17/02/22.
//


import Foundation

struct Constants {
    
    struct Urls {
        
        static func urlForWeatherByCity(city: String) -> URL? {
            
            // get the default settings for temperature
           // let userDefaults = UserDefaults.standard
           // let unit = (userDefaults.value(forKey: "unit") as? String) ?? "imperial"
            
            return URL(string: "http://dataservice.accuweather.com/locations/v1/cities/autocomplete?q=\(city)&apikey=iDyUTSpAMQuh2lxlfn5rEWJfxIomGAYu")
        }
        
        static func urlForWeatherByKey(cityKey:String) -> URL?{
            return URL(string: "http://dataservice.accuweather.com/currentconditions/v1/\(cityKey)?apikey=iDyUTSpAMQuh2lxlfn5rEWJfxIomGAYu")
        }
        
        
    }
    
}

