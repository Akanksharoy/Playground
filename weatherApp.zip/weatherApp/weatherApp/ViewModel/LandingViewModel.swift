//
//  LandingViewModel.swift
//  weatherApp
//
//  Created by Akanksha on 17/02/22.
//

import Foundation
class LandingViewModel{
    
    private  var products:[LandingDataModel] = []
    
    func getSearchCities(searchText:String, completion: @escaping (Result<[LandingDataModel], Error>) -> Void){
        Webservice().getSearchCityWeatherData(searchText: searchText) {
            (results) in
            switch results {
            case let .success(LandingDataModel):
                self.products = LandingDataModel
            case let .failure(error):
                print(error)
                
            }
            completion(results)
        }
        
    }
    var totalNumberOfCities:Int{
        get {
            return products.count
        }
        
    }
    func getCityName(index:Int) -> String{
        
        return products[index].LocalizedName
    }
    func getKey(index:Int) -> String{
        return products[index].Key
    }
}
