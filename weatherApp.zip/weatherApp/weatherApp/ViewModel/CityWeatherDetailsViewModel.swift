//
//  CityWeatherDetailsViewModel.swift
//  weatherApp
//
//  Created by Akanksha on 18/02/22.
//

import Foundation

class CityWeatherDetailsViewModel{
    
    var cityWeatherDataModel:[CityWeatherDataModel]?
    
    var locationKey:String
    init(locationKey:String){
        self.locationKey = locationKey
    }
    

    
    func getCityData(cityKey:String, completion: @escaping () -> Void){
        Webservice().getCityWeatherData(cityKey: cityKey) {
            (results) in
            switch results {
            case let .success(cityWeatherDataModel):
                print("fetched data")
                self.cityWeatherDataModel = cityWeatherDataModel
            case let .failure(error):
                print(error)
                
            }
            completion()
        }
        
    }
    
    
    
    
    
    
}


