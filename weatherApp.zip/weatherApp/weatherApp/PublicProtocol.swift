//
//  PublicProtocol.swift
//  weatherApp
//
//  Created by Akanksha on 14/02/22.
//

protocol Navigator {
    associatedtype Destination

    func navigate(to destination: Destination)
}
